import React from 'react';

const Profile = () => {
    return (
        <div style={{ padding: '100px', color: 'white' }}>
            <h1>Your Profile</h1>
            <p>Tu pojawi si� zawarto�� profilu u�ytkownika.</p>
        </div>
    );
};

export default Profile;
