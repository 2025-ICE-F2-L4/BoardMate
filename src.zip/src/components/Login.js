import React from 'react';

const Login = () => {
    return (
        <div style={{ padding: '100px', color: 'white' }}>
            <h1>Login Page</h1>
            <p>Tutaj bedzie logowanie/rejestracja.</p>
        </div>
    );
};

export default Login;
